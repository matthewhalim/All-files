def read_movie_data(filename):      #a function that reads every line of the file
    movie_data = [] #an empty list that will contain ALL movie information based on the headers
    with open(filename, 'r') as file:
        header = file.readline().strip().split(',') #splits the header into lists seperated by whitespace and commas
        for line in file:
            movie = line.strip().split(',') #seperates the information aside from the header by commas and whitespace
            movie_data.append(dict(zip(header, movie))) #zips the information into headers, with the headers the key containing movie information as the values
    return movie_data

# (1) Top-3 movies with the highest ratings in 2016
def top_3_movies_2016(movie_data):  #function for second question
    movies_2016 = [movie for movie in movie_data if movie['Year'] == '2016']    #list of movies that came out in 2016. The logic here is we list the movies if the movie on
    #the key 'Year' is 2016
    sorted_movies = sorted(movies_2016, key=lambda x: float(x['Rating']), reverse=True) #a new function we learned, key and lambda. Key assigns the lambda function as a key to
    #a dictionary while lambda creates a small function with x as the variable and the code after ':' as the argument
    # We then sort it based on the ratings by using the key= lambda function. We reverses it because sort sorts it in ascending order
    top_3 = [movie['Title'] for movie in sorted_movies[:3]] #prints out the top 3 movies
    return top_3

# (2) The director who involves in the most movies
def most_movies_director(movie_data):   #function for directors with most movies
    director_counts = {}
    for movie in movie_data:
        director = movie['Director']    #acceses the movie under the 'Director' header
        director_counts[director] = director_counts.get(director, 0) + 1    #counts how many times the the each director gets mentioned by using the dictionary function 'get'
    most_movies_director = max(director_counts, key=director_counts.get)    #max to get the highest ammount of times a director is mentioned and turns it into the key
    return most_movies_director

def highest_revenue_actor(movie_data): #function for question 3
    actor_revenue = {}  #empty dictionary for revenue
    for movie in movie_data:
        actors = movie['Actors'].split('| ')    #computes all actor. splits by '| ' because most movies have multiple actors seperated by '| '
        revenue = movie['Revenue (Millions)']   #finds the revenue headaer
        if revenue != 'N/A' and revenue != '':  #only computes movies with known revenues
            for actor in actors:
                actor_revenue[actor] = actor_revenue.get(actor, 0) + float(revenue) #actor revenue is all the revenue the film the actor appeared in generates
    highest_revenue_actor = max(actor_revenue, key=actor_revenue.get)   #same usage of key and max as before
    return highest_revenue_actor

# (4) The average rating of Emma Watson's movies
def emma_watson_average_rating(movie_data):
    emma_watson_movies = [movie for movie in movie_data if 'Emma Watson' in movie['Actors']]
    ratings = [float(movie['Rating']) for movie in emma_watson_movies]  #gets the information by accessing Actors key and only search eevrytime Emma Watson is mentioned
    average_rating = sum(ratings) / len(ratings) #formula for average/mean
    return average_rating

# (5) Top-4 actors playing the most movies
def top_4_actors_movies(movie_data):    #this function is simillar to the director with most films part. Difference is, we search up how many times the Actors name appeared
    actor_counts = {}
    for movie in movie_data:
        actors = movie['Actors'].split('| ')
        for actor in actors:
            actor_counts[actor] = actor_counts.get(actor, 0) + 1
    sorted_actors = sorted(actor_counts, key=actor_counts.get, reverse=True)
    top_4_actors = sorted_actors[:4]
    return top_4_actors

# (6) Top-7 frequent collaboration pairs of director & actor
def top_7_collaboration_pairs(movie_data):  #this is also simillar to the director and actor appearing in how many films question, but this time find how many the same 2 actor
    #and director names are mentioned
    collaboration_counts = {}
    for movie in movie_data:
        director = movie['Director']
        actors = movie['Actors'].split('| ')
        for actor in actors:
            pair = (director, actor)
            collaboration_counts[pair] = collaboration_counts.get(pair, 0) + 1
    sorted_collaborations = sorted(collaboration_counts, key=collaboration_counts.get, reverse=True)
    top_7_collaborations = sorted_collaborations[:7]
    return top_7_collaborations

# (7) Top-3 directors who collaborate with the most actors
def top_3_director_collaborations(movie_data):  #simillar to question 6, but this time, compares the director names with the actor names instead of the movie names
    director_actor_counts = {}
    for movie in movie_data:
        director = movie['Director']
        actors = movie['Actors'].split('| ')
        for actor in actors:
            pair = (director, actor)
            director_actor_counts[pair] = director_actor_counts.get(pair, 0) + 1
    director_counts = {}
    for pair in director_actor_counts:
        director = pair[0]
        director_counts[director] = director_counts.get(director, 0) + 1
    sorted_directors = sorted(director_counts, key=director_counts.get, reverse=True)
    top_3_directors = sorted_directors[:3]
    return top_3_directors

# (8) Top-6 actors playing in the most genres of movies
def top_6_actors_genres(movie_data):    #Simillar as previous questions, but compares the actor names with the movie genres.
    actor_genre_counts = {}
    for movie in movie_data:
        actors = movie['Actors'].split('| ')
        genres = movie['Genre'].split('| ') #seperate by '| ' because genres are also seperated by it, like actors
        for actor in actors:
            for genre in genres:
                pair = (actor, genre)
                actor_genre_counts[pair] = actor_genre_counts.get(pair, 0) + 1
    actor_counts = {}
    for pair in actor_genre_counts:
        actor = pair[0]
        actor_counts[actor] = actor_counts.get(actor, 0) + 1
    sorted_actors = sorted(actor_counts, key=actor_counts.get, reverse=True)
    top_6_actors = sorted_actors[:6]
    return top_6_actors

# (9) Top-3 actors whose movies lead to the largest maximum gap of years
def calculate_max_year_gap(movie_years):       #function to find the biggest gaps between movies in every actor
    sorted_years = sorted(movie_years)  #first of all, this function sorts in ascending order all movies every actor appears in by their years
    max_gap = 0
    for i in range(1, len(sorted_years)):   #checks each movie seperated by a distance of 1 movie each and replaces each gap years for every time a gap in movies is bigger
        gap = sorted_years[i] - sorted_years[i-1]
        if gap > max_gap:
            max_gap = gap
    return max_gap

def top_3_actors_max_year_gap(movie_data):  #the function to find the actor with max gap
    actor_year_movies = {}
    for movie in movie_data:
        actors = movie['Actors'].split('| ')
        year = int(movie['Year'])
        for actor in actors:
            if actor in actor_year_movies:
                actor_year_movies[actor].append((year, movie['Title']))
            else:
                actor_year_movies[actor] = [(year, movie['Title'])] #finds all the movies, actors, and years

    sorted_actors = sorted(actor_year_movies, key=lambda x: calculate_max_year_gap([year for year, _ in actor_year_movies[x]]), reverse=True)
    top_3_actors = sorted_actors[:3]    #sorts actors based on the gap. sets the gap year as the  key. finds the year and actor name to put into the max year gap function

    top_3_actors_info = []
    for actor in top_3_actors:  #the previous part only mentions the information seperately. We append the information into the top 3 actors info per movies, gap, and years
        movies = actor_year_movies[actor]
        years = [year for year, _ in movies]
        max_gap = calculate_max_year_gap(years)
        reference_movie = max(movies, key=lambda x: x[0])[1]
        top_3_actors_info.append((actor, max_gap, reference_movie))

    return top_3_actors_info

# Read the movie data from CSV
movie_data = read_movie_data('IMDB-Movie-Data.csv')

# Call the functions to get the answers and print the results
print("1. Top 3 movies with the highest ratings in 2016:")
print(top_3_movies_2016(movie_data))
print("\n2. Director involved in the most movies:", most_movies_director(movie_data))
print("\n3. Actor generating the highest total revenue:", highest_revenue_actor(movie_data))
print("\n4. Average rating of Emma Watson's movies:", emma_watson_average_rating(movie_data))
print("\n5. Top 4 actors playing the most movies:")
print(top_4_actors_movies(movie_data))
print("\n6. Top 7 frequent collaboration pairs of director & actor:")
print(top_7_collaboration_pairs(movie_data))
print("\n7. Top 3 directors who collaborate with the most actors:")
print(top_3_director_collaborations(movie_data))
print("\n8. Top 6 actors playing in the most genres of movies:")
print(top_6_actors_genres(movie_data))
print("\n9. Top 3 actors whose movies lead to the largest maximum gap of years:")   #uses f to get the keys and values in the string
for actor_info in top_3_actors_max_year_gap(movie_data):
    actor, gap, reference_movie = actor_info
    print(f"Actor: {actor}, Gap: {gap}, Reference Movie: {reference_movie}")
