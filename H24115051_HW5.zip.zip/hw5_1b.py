import random

class Blackjack:
    def __init__(self):
        self.ranks = ["ACE", "2", "3", "4", "5", "6", "7", "8", "9", "10", "JACK", "QUEEN", "KING"]
        self.suits = ["SPADE", "HEART", "DIAMOND", "CLUB"]
        self.deck = []
        self.player_value = 0
        self.dealer_value = 0
        self.drawn_cards = []
        self.player_hand = []
        self.dealer_hand = []
        self.current_cards = []
        self.current_hand_str = ''
        self.current_dealer_cards = []
        self.current_dealer_hand_str = ''

    def create_deck(self):
        temp_deck = []
        for suit in self.suits:
            for rank in self.ranks:
                temp_deck.append(f"{rank} {suit}")
        random.shuffle(temp_deck)
        for card in temp_deck:
            self.deck.append(card.split())

    def draw_card(self):
        card_index = random.randint(0, len(self.deck) - 1)
        self.drawn_cards.append(self.deck[card_index])
        self.deck.pop(card_index)

    def initial_deal(self):
        for _ in range(4):
            self.draw_card()
        self.player_hand.extend(self.drawn_cards[:2])
        self.dealer_hand.extend(self.drawn_cards[2:])
        self.drawn_cards.clear()

    def count_player_value(self):
        self.player_value = 0
        for card in self.player_hand:
            if card[0].isdigit():
                self.player_value += int(card[0])
            elif card[0] in ['JACK', 'QUEEN', 'KING']:
                self.player_value += 10
            elif card[0] == 'ACE':
                if self.player_value <= 10:
                    self.player_value += 11
                else:
                    self.player_value += 1

    def count_dealer_value(self):
        self.dealer_value = 0
        for card in self.dealer_hand:
            if card[0].isdigit():
                self.dealer_value += int(card[0])
            elif card[0] in ['JACK', 'QUEEN', 'KING']:
                self.dealer_value += 10
            elif card[0] == 'ACE':
                if self.dealer_value <= 10:
                    self.dealer_value += 11
                else:
                    self.dealer_value += 1

    def player_turn(self):
        while True:
            self.current_cards = ['-'.join(card) for card in self.player_hand]
            self.current_hand_str = ', '.join(self.current_cards)
            if self.player_value < 21:
                print(f'\nYour current value is {self.player_value}')
                print(f'with the hand: {self.current_hand_str}')
            elif self.player_value == 21:
                print('Your current value is Blackjack! (21)')
                print(f'with the hand: {self.current_hand_str}')
                return False
            elif self.player_value > 21:
                print('Your current value is Bust (>21)')
                print(f'with the hand: {self.current_hand_str}')
                print('\n*** Dealer Wins ***!')
                return False

            self.current_cards.clear()
            self.current_hand_str = ''
            choice = int(input('\nHit or stay? (Hit = 1, Stay = 0):'))
            if choice == 0:
                self.count_dealer_value()
                self.dealer_turn()
                return
            elif choice == 1:
                self.draw_card()
                print(f'You draw {"-".join(self.drawn_cards[0])}')
                self.player_hand.append(self.drawn_cards[0])
                self.drawn_cards.clear()
                self.count_player_value()
                self.current_cards.clear()
                self.current_hand_str = ''

    def dealer_turn(self):
        self.current_dealer_cards = ['-'.join(card) for card in self.dealer_hand]
        self.current_dealer_hand_str = ', '.join(self.current_dealer_cards)
        if 17 <= self.dealer_value <= 21:
            print(f'\nDealer\'s current value is {self.dealer_value}')
            print(f'with the hand: {self.current_dealer_hand_str}')
            if self.dealer_value < self.player_value:
                print('\n*** You beat the dealer! ***')
                return False
            elif self.dealer_value == self.player_value:
                print('\n*** You tied the dealer, nobody wins. ***')
                return False
            elif self.dealer_value > self.player_value:
                print('\n*** Dealer wins! ***')
        elif self.dealer_value > 21:
            print('Dealer\'s current value is Bust (>21)')
            print(f'with the hand: {self.current_dealer_hand_str}')
            print('\n*** You beat the dealer! ***')
            return False
        elif self.dealer_value == 21 and self.dealer_value > self.player_value:
            print('Dealer\'s current value is Blackjack (21)')
            print(f'with the hand: {self.current_dealer_hand_str}')
            print('\n*** Dealer wins! ***')
            return False

        self.current_dealer_cards.clear()
        self.current_dealer_hand_str = ''
        if self.dealer_value < 17:
            self.draw_card()
            print(f'Dealer draws {"-".join(self.drawn_cards[0])}')
            self.dealer_hand.append(self.drawn_cards[0])
            self.drawn_cards.clear()
            self.count_dealer_value()
            self.current_dealer_cards.clear()
            self.current_dealer_hand_str = ''
            self.dealer_turn()

def start_game():
    game = Blackjack()
    game.create_deck()
    game.draw_card()
    game.initial_deal()
    game.count_player_value()
    game.player_turn()
    again = input('Want to play again? (y/n):')
    if again == 'y':
        print('\n' + '-' * 40)
        start_game()
    else:
        quit()

start_game()
