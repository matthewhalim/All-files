a =  int(input ("Input the range number:"))

for x in range (1, a+1):
    h = 0
    for y in range (1,x):
        if x % y == 0:
            h += y
    if h == x:
        print(h)



