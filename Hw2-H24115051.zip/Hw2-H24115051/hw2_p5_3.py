requested_fibonacci_element = input("The number of the requested element in Fibonacci (n): ")
fibonacci_n1 = 0


if requested_fibonacci_element.isdigit():
    fibonacci_n1 = 0
    fibonacci_n2 = 1
    requested_fibonacci_element = int(requested_fibonacci_element)


    for i in range(1, requested_fibonacci_element + 1):
        fibonacci_n1, fibonacci_n2 = fibonacci_n2, fibonacci_n1 + fibonacci_n2
else:
    print("Please input a non-decimal number!")


first_string = input("The first string for palindromic detection (s1): ").lower()
second_string = input("The second string for palindromic detection (s2): ").lower()


length_first_string = len(first_string)
length_second_string = len(second_string)


max_length_1 = 0
longest_substring_1 = ""
for i in range(length_first_string):
    for j in range(i + 1, length_first_string + 1):
        substring = first_string[i:j]
        if substring == substring[::-1] and len(substring) > max_length_1:
            max_length_1 = len(substring)
            longest_substring_1 = substring


max_length_2 = 0
longest_substring_2 = ""
for i in range(length_second_string):
    for j in range(i + 1, length_second_string + 1):
        substring = second_string[i:j]
        if substring == substring[::-1] and len(substring) > max_length_2:
            max_length_2 = len(substring)
            longest_substring_2 = substring


length_longest_substring_1 = len(longest_substring_1)
length_longest_substring_2 = len(longest_substring_2)


plaintext = input("The plaintext to be encrypted:").strip()
encrypted_text = ""
for char in plaintext:
    char_code = ord(char) + fibonacci_n1
    encrypted_char_code = char_code * length_longest_substring_1 + length_longest_substring_2
    if encrypted_char_code > 90:
        encrypted_char_code = ((encrypted_char_code - 65) % 26) + 65
    if encrypted_char_code < 90:
        encrypted_char_code = encrypted_char_code
    encrypted_char = chr(encrypted_char_code)
    encrypted_text += encrypted_char


print("----- extract key for encrypt method -----")
print("The %d-th Fibonacci sequence number is:" % requested_fibonacci_element, fibonacci_n1)
print("Longest palindrome substring within the first string is:", longest_substring_1)
print("Length is:", length_longest_substring_1)
print("Longest palindrome substring within the second string is:", longest_substring_2)
print("Length is:", length_longest_substring_2)
print("----- encryption completed -----")
print("The encrypted text is:", encrypted_text)
