num_layers = input("Enter the number of layers (2 to 5): ")
top_triangle_side_length = input("Enter the side length of the top triangle (2 to 6): ")
growth_rate = input("Enter the growth rate of each layer: ")
trunk_width = input("Enter the trunk width (odd number, 3 to 9): ")
trunk_height = input("Enter the trunk height (4 to 10): ")

if num_layers.isdigit() and top_triangle_side_length.isdigit() and trunk_height.isdigit() and growth_rate.isdigit() and trunk_width.isdigit():
    num_layers = int(num_layers)
    top_triangle_side_length = int(top_triangle_side_length)
    growth_rate = int(growth_rate)
    trunk_width = int(trunk_width)
    trunk_height = int(trunk_height)

    if 2 <= num_layers <= 5 and 4 <= trunk_height <= 10 and trunk_width % 2 != 0 and 3 <= trunk_width <= 9 and 2 <= top_triangle_side_length <= 6:
        base_width = (2 * ((top_triangle_side_length - 1) + (num_layers - 1) * growth_rate) + 1)
        top_triangle = " " * (base_width // 2) + "#"
        print(top_triangle)
        for layer in range(1, num_layers + 1):
            for i in range(1, top_triangle_side_length + growth_rate * (layer - 1) - 1):
                mid_section = " " * (base_width // 2 - i) + "#" + "@" * (i + (i - 1)) + "#"
                print(mid_section)
            base_section = " " * (
                        base_width // 2 - (top_triangle_side_length - 1) - growth_rate * (layer - 1)) + "#" * (
                                       2 * (top_triangle_side_length + (layer - 1) * growth_rate) - 1)
            print(base_section)
        for i in range(1, trunk_height + 1):
            trunk = " " * (base_width // 2 - trunk_width // 2) + "|" * trunk_width
            print(trunk)
