s1 = "spam"
s2 = "ni!"
#a
print("The Knights who say," + s2)
#b
print(3 * s1 + 2 * s2)
#c
print(s1[1])
#d
print(s1[1:3])
#e
print(s1[2]+ s2[:2])
#f
print(s1 + s2[-1])
#g
print(s2[len(s2)//2])

#Problem 1-2
#a
a2 = s2.upper()
print(a2)
#b
b2= s2 + s1 + s2
print(b2)
#c
c2 = s1.replace("m","n")
print(c2)
#d
d2 = s1.replace("a","")
print(d2)

#Problem 1-3
#a
print("Looks like %s and %s for breakfast" % ("spam", "eggs"))
#b
print("There is %d %s %d %s" % (1, "spam", 4, "you"))
#c
#print("Hello %s" % ("Suzie", "Programmer"))
#c3 =print("Hello %s" % ("Suzie", "Programmer")) is wrong because there is only one string  which formats to the value "Suzie".
#d
print("%0.2f %0.2f" % (2.3, 2.3468))
#e
print( "%7.5f %7.5f" % (2.3, 2.3468))
#f
print("Time left %02d:%05.2f" % (1, 37.374) )
#g
#print("%3d" % ("14") )
#this gives an error due to "14" is a string and %d is for formatting integer values.2

#Problem 1-4
x1 = 5 #set variable x
y1 = 3 #set variable y
if x1 >= y1: # if condition if x is bigger or equal to y
    x2 = x1 - 2 # if "if" condition is fulfilled then this condition will be executed
print(x2) #print x


tc = 100 #set variable tc
tf = (9/5) * tc + 32 # set variable tf with multiplication and addition
print(tf) #print the variable tf


x3 = 0 #set variable x to 0
while x3 < 5: # "while" statement to check if the value x3 is lesser than 5, if x3 is bigger than 5 then this line wont be executed
    x3 = x3 + 1 #while x3<5 then this line is executed which is x3 +1
print(x3) #it will print 5 since the iteration stop at 4 because when its in the 5th iteration, 4+1 =5 and therefore the next iteration will be 5>5 which is false .

x4 = 1 #set value for x
i4 = 1 #set value for i
while x4 <= 5: #"while" condition that needs to be fulfilled
    x4 = x4 * i4 #so long as x4 is smaller or equal to 5 then this condition is going to be executed
    i4 = i4+1##new value for i as long as the "while" condition, x being less than or equal to 5, is true
print(x4)#prints (after a 5-time loop) the value of x, which is 6. The idea is roughly the same as in issue (c), but instead of using less than 5, it utilizes less than or equal to 5. Additionally, the result's equation is altered, although it has no effect because the x value equals 1.


x5 = 0  #set value for x
while x5 < 6: #"while" conditional that needs to be fulfilled which is x5<6
    if x5 % 2 == 0: #"if" conditional that needs to be fulfilled as long as "while" condition, x being less than 6, is true
        print('even', x) ##the action done if "if" condition, modulus(remainder) of x divided by 2 is equal to 0, is true. The action is print the string "even: and integer x
    else:#"else" statement to execute this  action if the "if" value is false
        print('odd', x)#the action done if "if" statement is false. which is printing the "odd" string and integer x
     x5 = x5 + 1 #makes sure that the program ends by increasing the x value by 1 after each loop so the while condition will eventually be false
#the resulting print will either show odd and the number if the number is odd, and even and the number if the number is even. the result will always change
#since it always loops until x is less equal to or more than 6. All the results are printed because the "print" command is inside of the "while" function


i6 = 0                      #set value for i
while i6 < 6:               #"while" condition,i being less than 6, that needs to be true to perform an action
    j6 = 0                  #set value for j
    while j6 < i6:          #"while" condition that needs to be true to perform an action as long as the previous "while" condition is true
        print("*")          #action done as long as the second "while" condition,j being less than i, is true, which is printing the "*" string
        j6 = j6 + 1         #makes sure the program ends by increasing the j value by one each loop so the while condition will eventually be false
    i6 = i6 + 1             #makes sure the program ends by increasing the i value by one each loop so the while condition will eventually be false
    print()                 #prints a new paragraph after every loop is done
#note: the amount of "*" keeps on increasing after every loop because the value of j5 always starts at 0 while the value of i5 that j6 needs to be less than
#keeps on increasing until it eventually stops when it hits an integer less than 6 (which is 6). The stars are all printed because there is an indent infront
#of the "print" command meaning the command is done continuously until the loop ends.

score = 40                  #set value for the "score" variable
while score > 1:            #"while" condition,the "score" variable being bigger than 1, that needs to be true for an action be done
    score = score/2 - 1     #action done as long as the while condition is true, which is dividing the score by 2 and subtracting it by 1
print(score)                #prints the new variable after the "while" statement
#note: the result is 0.625 because the program will run until score < 1 and will print only one result which is 0.625

x8 = 2           #set value for x
y8 = 7           #set value for y
while x8 < y8:    #"while" condition, x being less than y, that needs to be true for the action to be done
    x8 = 2 * x8   #the action done as long as the "while" condition is true
print(x8)        #prints the new value of x after the "while" statement because the command is outside of the while statement

a9, b9 = 63, 105            #set value for variable a and b
while b9:                   #"while" conditions that run an action as long as the value of the variable b does not change
    a9, b9 = b9, a9 % b9    #set variable a equal to variable b after the "while" statement. Set variable b after the "while" statement as the
                            #modulus(remainder) of a divided by b
print(a9)                    #prints the value of a after the while statement
print(b9)                   #prints the value of b after the while statement
#note: the loop happens 3 times. The first changes the value of a into 105 and b into 63. The second changes a into 63 and b into 42. The last results in
#the printed value of 21. The loop does not happen for the 4th time because the modulus result is 0. "While" loops will only loop if the value is true and
#non-zero. Last value for a is 21 and not 0 because since 0 is the last value of b, b

n10 = 21                      #set value for n
while n10 != 1:               #"while" condition, n not equal to 1, that needs to be true to run an action
    print(n10, end=", ")      #the action that is done as long as the "while" condition is true which is printing the variable n and ", " behind n
    if n10 % 2 == 0:          #"if" condition n modulus 2 is equal to 0 ("==" ignores the datatypes of the 2 variable).
        n10 = n10 // 2        #the new value for n if the "if" condition is true, which is n (floor) divided by 2 and rounded to the left.
    else:                     #sets an action that would be done if the "if" condition is false
       n10 = n10 * 3 + 1      #the new value for n if the "if" condition is false, which is n times 3 plus 1
    print(n10, end=".\n")     #as long as the "while" condition is true, it will print the new variable n, a period behind n, and a new paragraph


#Proble 1-5
x10 = 7 # set variable x
y10 = 8 #set variable y
if x10 < 7 or x10 <= 10 and y10 > 8: #
    print("ugh")
else:
    print("yuck")
#the result will be yuck because 7<10 but 8>8 is false therefore if is not fulfilled therefore else

phrase = "python"                       #sets the variable "phrase" value as the string "python"
vowels = "aeiou"                        #sets the value of the variable "vowels" as the string "aeiou"
count = 0                               #sets the value of the variable "count" as the integer 0
while (not phrase[count] in vowels):    #sets "while" condition, starting from the first character in the string, as long as there is no characters in
                                        #variable phrase that is not also in the variable "vowels".
    count = count + 1                   #the action done as long as the "while" condition is true, which is adding the variable count by 1.
print(count)                            #prints the contents of the variable count after the "while" loop ends
#note:We use square brackets to identify the numerical position of the characters in our string starting from 0. Since the variable "count" is an integer, 0,
#it will scan the characters starting from the first character. By using the "not" relational operator and "while" loop as well as the "count = count +1"
#command, it will continuously increasing the value of "count" therefore makaing it scan the characters 1 by 1 to the right until it finds a character in
#the variable "vowels", which in this case is in the 4th position of the "phrase" variable, which is the letter o.


if 'alpha' < 'zebra':           #sets "if" condition, if the string 'alpha' is less than the string 'zebra', do a certain action
    print('alpha < zebra')      #the action done, which is printing the string 'alpha < zebra'
elif 'alpha' > 'zebra':         #sets another "if" condition if the first "if" condition is false, which is 'alpha' bigger than 'zebra'
    print('alpha > zebra')      #the action done if first "elif" is true, prints the string 'alpha > zebra'
elif 'alpha' == 'zebra':        #another "if" condition if the first "elif" condition is false, which is 'alpha' being equal to 'zebra'
    print('alpha == zebra')     #the action done if the second "elif" condition is true, prints the string 'alpha == zebra'
else:                           #runs an action if all cocnditions above are false
    print('none of the above')  #the action done if all conditions above are false, prints the string 'none of the above'
#note: the resulting print will be 'alpha < zebra' because based on the lexicographic order, the letter a comes before the letter z making a "less than" z

#Part 1-6
thief = 1
while thief <= 4:
    if thief == 1 and thief == 3 and thief == 4 and thief != 4:
        print("The thief is",thief)
    elif thief != 1 and thief != 3 and thief == 4 and thief != 4:
        print("The thief is",thief)
    elif thief != 1 and thief == 3 and thief != 4:
        print("The thief is",thief)
    elif thief != 1 and thief == 3 and thief == 4:
        print("The thief is",thief)
    thief = thief + 1




