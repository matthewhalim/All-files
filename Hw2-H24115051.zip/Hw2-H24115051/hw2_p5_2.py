S = input("The first string for palindromic detection (s1) = ").lower()
max_ = 0
sub = ""
for i in range(count):
    for x in range(i+1, count+1):
        str_ = S[i:x]
        if str_ == str_[::-1] and len(str_) > max_:
            max_ = len(str_)
            sub = str_
s = len(sub)
print("Longest palindrome substring within the first string is:", sub)
print("Length is:", s)
