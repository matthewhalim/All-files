class ConnectFour:
    def __init__(self, rows=6, columns=7):
        self.rows = rows
        self.columns = columns
        self.board = [['|   ' for _ in range(columns)] for _ in range(rows)]

    def display_board(self):
        print("+---" * self.columns + "+")
        for row in self.board:
            print(''.join(row))
            print("+---" * self.columns + "+")
        print('  '.join(f' {i} ' for i in range(self.columns)))

    def make_move(self, player, col):
        if col < 0 or col >= self.columns:
            raise ValueError("Column index out of bounds.")
        for row in reversed(self.board):
            if row[col] == '|   ':
                row[col] = f'| {player} '
                return True
        raise ValueError("Column is full. Please choose another column.")

    def is_full(self):
        return all(row[0] != '|   ' for row in self.board)

    def check_win(self):
        # Check all rows, columns, and diagonals
        lines = []
        # Rows
        lines.extend(self.board)
        # Columns
        for col in range(self.columns):
            lines.append([self.board[row][col] for row in range(self.rows)])
        # Diagonals
        for d in range(-self.rows + 1, self.columns):
            lines.append([self.board[r][r + d] for r in range(max(-d, 0), min(self.rows, self.columns - d)) if 0 <= r + d < self.columns])
            lines.append([self.board[r][d - r] for r in range(max(d, 0), min(self.columns + d, self.rows)) if 0 <= d - r < self.columns])

        # Check for four of the same player in any line
        for line in lines:
            for i in range(len(line) - 3):
                if line[i] == line[i + 1] == line[i + 2] == line[i + 3] != '|   ':
                    return line[i][2]
        return None

    def start_game(self):
        current_player = 'X'
        while True:
            self.display_board()
            try:
                col = int(input(f'Player {current_player} >> '))
                self.make_move(current_player, col)
            except ValueError as e:
                print(e)
                continue

            winner = self.check_win()
            if winner:
                print(f"Winner: {winner}")
                break
            if self.is_full():
                print("Draw")
                break
            current_player = 'O' if current_player == 'X' else 'X'

# Usage
game = ConnectFour()
game.start_game()
