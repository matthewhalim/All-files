
polynomial_input = input('Input polynomial: ')          # Lets user input the polynomial
x_value = int(input('Input the value of X: '))           # Lets user input the value of variable x
start_index = 0                                          # Initial index for slicing
total_result = 0                                         # Initializes the total result variable
expression_elements = []                                 # Initializes list to hold parts of the expression

# Ensure the polynomial starts positively if the first character is a minus
if polynomial_input[0] == "-":
    polynomial_input = "0" + polynomial_input

# Parse the polynomial to separate elements and operators
for index, char in enumerate(polynomial_input):
    if char in '+-*^':                                   # Check for operators
        segment = polynomial_input[start_index:index]    # Extract segment before the operator
        expression_elements.append(segment)
        expression_elements.append(char)
        start_index = index + 1                          # Update start index after the operator
    if index == len(polynomial_input) - 1:               # Ensure the last segment is added
        segment = polynomial_input[start_index:]
        expression_elements.append(segment)

# Replace 'X' with its numerical value and convert digits to integers
for index, element in enumerate(expression_elements):
    if element == 'X':
        expression_elements[index] = x_value
    elif element.isdigit():
        expression_elements[index] = int(element)

# Process power operations first
index = 0
while index < len(expression_elements):
    if expression_elements[index] == '^':
        powered_result = expression_elements[index-1] ** expression_elements[index+1]
        expression_elements[index-1] = powered_result
        del expression_elements[index:index+2]           # Remove the used elements
        index -= 1                                       # Adjust index to recheck new current position
    index += 1

# Process multiplication operations
index = 0
while index < len(expression_elements):
    if expression_elements[index] == '*':
        multiplied_result = expression_elements[index-1] * expression_elements[index+1]
        expression_elements[index-1] = multiplied_result
        del expression_elements[index:index+2]
        index -= 1
    index += 1

# Initialize the result with the first number if it's an integer
if isinstance(expression_elements[0], int):
    total_result = expression_elements[0]

# Add and subtract the remaining elements
index = 1
while index < len(expression_elements):
    if expression_elements[index] == '-':
        total_result -= expression_elements[index+1]
        index += 2
    elif expression_elements[index] == '+':
        total_result += expression_elements[index+1]
        index += 2

print("Evaluated Result: ", total_result)
