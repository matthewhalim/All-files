total_students_input = input('Input the total number of students (n>0) : ')
if total_students_input.isdigit():
    total_students = int(total_students_input)
    if total_students > 0:
        students_list = list(range(1, total_students + 1))
        current_index = 0
        while len(students_list) > 1:
            current_index = (current_index + 2) % len(students_list)
            students_list.pop(current_index)
        last_student_id = students_list[0]
        print('The last ID is : ', last_student_id)
    else:
        print("Please enter a positive number!")
else:
    print("Please enter a non-decimal number!")





