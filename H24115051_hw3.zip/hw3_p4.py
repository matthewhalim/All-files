def replace_color(mat, x, y, k):     #makes a function for replacing colors
    loc = mat[x][y]                  #the location of the color
    rows = len(mat)               #sets variable rows to indicate the row entered
    cols = len(mat[0])            #sets the varuable cols to indicate the collumn
    done = set() #set is a new function learned that makes sure a value is only gone through once, therefore not be repeated
    def rep(i, j):  #define function that checks for mistakes
        if i < 0 or i >= rows or j < 0 or j >= cols or mat[i][j] != loc or (i,j) in done:    #if color is out of bound, calls back to the beginning
            return
        mat[i][j] = k       #replaces the desired location of color into the value k
        done.add((i,j))     #makes sure it does not recheck the same value
        rep(i-1, j)         #checks adjacent values in 4 directions
        rep(i+1, j)
        rep(i, j-1)
        rep(i, j+1)
    rep(x, y)
    return mat              #calls the matrix

# lets user input the desired values
mat = []
nah = []
matr = 0
lists = []
x, y, k = input("Enter index x, y, k (separated by whitespace): ").split()  #seperates the x, y, k values into lists seperated by whitespace
x, y, k = int(x), int(y), int(k)        #converts the string datatype into an integer datatype
matrix = print("Enter the matrix by multiple lines:")
inp = []    #initial empty list for variable inp that can be modified later
while matrix != 'q':    #lets user continuosly enter line breaks as long as the user has not entered the character q
    inp.append(matrix)
    matrix = input()
new = inp[1:]           #removes the "None" datatype from the list
for i in range(len(new)):   #for loop that will loop from 0 upto the number of characters in mat list
    lists = new[i].split(" ")
    mat.append(lists)       #adds the values into a new list
result = replace_color(mat, x, y, k)    #calls the function defined before
for row in result:
    print(" ".join([str(x) for x in row]))  #joins the result so it does not print a list