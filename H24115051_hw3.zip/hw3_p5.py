def trap_rain_water(heights):
    if not heights:
        return 0

    n = len(heights)
    max_height = max(heights)
    water = 0

    # Create and fill the matrix
    matrix = [[0] * n for _ in range(max_height)]
    for i in range(n):
        for j in range(heights[i]):
            matrix[max_height - 1 - j][i] = 1

    # Calculate trapped water
    for row in matrix:
        start = -1
        for i in range(n):
            if row[i] == 1:
                if start != -1:
                    water += i - start - 1
                start = i

    return water

# Example usage:
heights_input = input("Input a sequence of heights separated by whitespace: ")
heights_list = list(map(int, heights_input.split()))
result = trap_rain_water(heights_list)
print("Water trapped:", result)
